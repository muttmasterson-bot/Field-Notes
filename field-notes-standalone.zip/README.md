# Field Notes for Reggora — standalone version

This is the same app, but built to run as its own website instead of inside
Claude — which is what lets the in-app microphone button actually work
(Claude's published pages run inside a restricted frame that never gets
microphone permission; a normal website does).

## What's different from the Claude-hosted version

- **Mic button works for real.** Chrome will ask for microphone permission
  the first time you tap it — allow it, and it dictates continuously.
- **Storage is on your phone**, not synced to the cloud. Notes and photos are
  saved in this browser's local storage (IndexedDB) on whichever device you
  use. If you switch phones or clear site data, you lose what's stored — so
  compile and copy/share anything important before that happens.
- **No AI analyze/draft buttons.** The checklist still auto-detects what
  you've covered (by keyword matching, on-device, no network needed) but the
  "ask Claude to draft this" step now happens by pasting your compiled notes
  into a normal Claude conversation yourself — Copy or Share on the Compile
  tab gets you there in one tap.

Everything else — the URAR/UAD 3.6 checklist, guided follow-ups for missing
fields, photo capture and tagging, compiled export — works the same way.

## How to put this online (free, ~5 minutes, no coding)

This uses GitHub Pages, a free static-hosting feature of GitHub.

1. Go to **github.com** and sign up for a free account if you don't already
   have one.
2. Click the **+** in the top right → **New repository**. Name it something
   like `field-notes` (it can be lowercase, no spaces). Leave it **Public**.
   Click **Create repository**.
3. On the new repo's page, click **Add file → Upload files**, then drag in
   all five files from this folder: `index.html`, `manifest.json`, `sw.js`,
   `icon-192.png`, `icon-512.png`. Click **Commit changes**.
4. Go to the repo's **Settings** tab → **Pages** (left sidebar). Under
   "Build and deployment," set **Source** to **Deploy from a branch**,
   **Branch** to **main** and folder **/ (root)**, then **Save**.
5. Wait about a minute, then refresh that Pages settings page — it'll show
   your live URL, something like `https://<your-username>.github.io/field-notes/`.
6. Open that link on your Android phone in Chrome. Tap the mic button once
   to test — allow the microphone permission when Chrome asks. From then on
   it's remembered.
7. Optional: in Chrome's menu (⋮), tap **Add to Home screen** so it opens
   like an app with its own icon.

To update the app later (if you ever want changes), you'd re-upload the
changed file(s) to the same repo the same way — Pages updates automatically
within a minute or two.
